#!/bin/bash

workflow/scripts/scrna-install-packages.R

#run again to test
workflow/scripts/scrna-install-packages.R
